<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Cursos <?php echo $__env->yieldContent('title'); ?></title>
	<?php echo $__env->yieldContent('head'); ?>
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>