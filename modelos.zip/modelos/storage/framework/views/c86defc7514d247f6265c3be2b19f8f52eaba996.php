<?php $__env->startSection('content'); ?>

	
   
	<?php if(!empty($errors->first())): ?>
		<?php $__env->startComponent('error', ['text' => $errors->first()]); ?>
		<?php echo $__env->renderComponent(); ?>
		
	<?php endif; ?>
	

		<table>
			
			<thead>
				<tr>
					<th>id</th>
					<th>nombre</th>
					<th>apellido</th>
					<th>fecha de nacimiento</th>
					<th>Kardex</th>
					<th>Acciones</th>
				</tr>
			</thead>
			
			<tbody>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($student->id); ?></td>
					<td> <a href=""><?php echo e($student->name); ?></a></td>
					<td><?php echo e($student->lastname); ?></td>
					<td><?php echo e($student->birthday); ?></td>
					<td><a href="/students/<?php echo e($student->id); ?>/grades">Ver </a> | <a href="/students/<?php echo e($student->id); ?>/grades/pdf"> Descargar </a></td>
					<td>
						<a href="">editar</a>
						<a href="">eliminar</a>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>