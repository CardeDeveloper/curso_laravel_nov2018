	<?php $__env->startSection('content'); ?>
		<form action="/cursos/<?php echo e($curso->id); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('PUT')); ?>

			<input value="<?php echo e($curso->nombre); ?>" type="text" name="nombre" placeholder="Nombre">
			<input value="<?php echo e($curso->descripcion); ?>" type="text" name="descripcion" placeholder="Descripcion">
			<input type="submit">
		</form>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>