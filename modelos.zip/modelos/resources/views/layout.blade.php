<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Cursos @yield('title')</title>
	@yield('head')
</head>
<body>
	@yield('content')
</body>
</html>