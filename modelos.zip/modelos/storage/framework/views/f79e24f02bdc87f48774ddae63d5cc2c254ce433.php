<?php $__env->startSection('content'); ?>
		<table>
			
			<thead>
				<tr>
					<th>id</th>
					<th>nombre</th>
					<th>descripcion</th>
					<th>acciones</th>
				</tr>
			</thead>
			
			<tbody>
			<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($curso->id); ?></td>
					<td> <a href=""><?php echo e($curso->nombre); ?></a></td>
					<td><?php echo e($curso->descripcion); ?></td>
					<td>
						<a href="">editar</a>
						<a href="">eliminar</a>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>