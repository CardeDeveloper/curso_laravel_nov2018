	<?php $__env->startSection('title'); ?>
		KARDEX
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('head'); ?>
		<style>
			#table-kardex{
				font-family: "Trebuchet MS, Arial, Helvetica, sans-serif";
				border-collapse: collapse;
				width: 70%;
				margin-left: 15%;

			}

			#table-kardex td, #table-kardex th{
				border: 1px solid #ddd;
				padding: 8px;
			}
			#table-kardex tr:nth-child(even){
				background-color: #f2f2f2;
			}

			#table-kardex th{
				padding-top:12px;
				padding-bottom: 12px;
				background-color: #4CAFF0;
				color: white; 
			}
		</style>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('content'); ?>
	
		<table id="table-kardex">
			<thead>
				<tr>
					<th>id</th>
					<th>materia</th>
					<th>descripcion</th>
					<th>calificacion</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($grade->id); ?></td>
					<td><?php echo e($grade->subject->name); ?></td>
					<td><?php echo e($grade->subject->description); ?></td>
					<td><?php echo e($grade->grade); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>