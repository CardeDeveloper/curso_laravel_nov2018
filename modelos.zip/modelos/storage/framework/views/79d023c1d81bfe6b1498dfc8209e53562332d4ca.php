<section >
	<div style="padding: 20px; background-color: #f44336; color: white;">
		<span onclick="this.parentElement.style.display='none'" style="margin-left: 15px; color: white; font-weight: bold; float: right; cursor: pointer; transition: 0.3s">&times;</span>
		<strong>Error!</strong>
		<?php echo e($text); ?>

	</div>
</section>