	<?php $__env->startSection('content'); ?>
		<form action="/cursos" method="POST">
			<?php echo e(csrf_field()); ?>

			<input type="text" name="nombre" placeholder="Nombre">
			<input type="text" name="descripcion" placeholder="Descripcion">
			<input type="submit">
		</form>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>